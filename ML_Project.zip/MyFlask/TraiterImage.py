# -*- coding: utf-8 -*-
"""
Created on Thu May  4 08:03:39 2023

@author: Kpodjro
"""
import cv2
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
import warnings
warnings.filterwarnings("ignore")

def img_augmentation(img):
    kernel = np.ones((3,3),np.uint8)
    kernel2D = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
    h, w = img.shape
    center = (w // 2, h // 2)
    M05a = cv2.getRotationMatrix2D(center, 15, 1.0)
    #M05b = cv2.getRotationMatrix2D(center, -15, 1.0)
    
    img_erode = cv2.erode(img, kernel)
    img_blur = cv2.GaussianBlur(img_erode,(3,3),0)
    img_closing = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel2D)
    
    img_rot5a = cv2.warpAffine(img, M05a, (w, h), borderValue=(255,255,255))
    #img_rot5b = cv2.warpAffine(img, M05b, (w, h), borderValue=(255,255,255))
    
    return [img_blur, img_closing, img_rot5a]


# Define the BoW function
def BoW(gray):
    
    sift = cv2.xfeatures2d.SIFT_create()
    keypoints, descriptors = sift.detectAndCompute(gray, None)

    # Convert descriptors to text
    text = [' '.join(map(str, d)) for d in descriptors]

    # Vectorize the text with BoW
    vectorizer = CountVectorizer() #vocabulary=list(set(vocabulary)))
    X = vectorizer.fit_transform(text)
    # Train a Naive Bayes classifier
    clf = MultinomialNB()
    clf.fit(X, text)

    # Compute the probability of each word given the image
    word_probs = []
    for i, word in enumerate(vectorizer.get_feature_names_out()):
        word_vec = np.zeros((1, len(vectorizer.vocabulary_)))
        word_vec[0, i] = 1
        word_prob = clf.predict_proba(word_vec)[:, 1]
        word_probs.append((word, word_prob))

    # Select the words with the highest probability
    caption_words = [word for word, prob in sorted(word_probs, key=lambda x: x[1], reverse=True)[:100]]

    # Convert the words to a caption
    caption = ' '.join(caption_words)

    return caption


def extract_features(images):
    # Resize all images to a fixed size
    resized_images = [cv2.imread(img,0) for img in images]

    # Convert images to grayscale
    features = [] # [cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) for img in resized_images]
    for img2 in resized_images :
        for img in img_augmentation(img2) :
            caption = BoW(img)     # Appel à la méthode BOW
            features.append(np.asarray(caption.split(), dtype=float))

    return features